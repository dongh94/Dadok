import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import { BootstrapVue, IconsPlugin } from "bootstrap-vue";
// ES6
import VueTyperPlugin from "vue-typer";
import VueSweetalert2 from "vue-sweetalert2";
import "sweetalert2/dist/sweetalert2.min.css";
import sal from "sal.js";
import "/node_modules/sal.js/dist/sal.css";

Vue.use(sal);
Vue.use(VueTyperPlugin);
Vue.config.productionTip = false;
Vue.use(BootstrapVue);
Vue.use(IconsPlugin);
Vue.use(VueSweetalert2);

Vue.use(VueTyperPlugin);
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap-vue/dist/bootstrap-vue.css";
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getStorage, ref } from "firebase/storage";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBNwPd4FTZAhDAJw9wUT1HsBewtyRg3YJM",
  authDomain: "dadok-c9f63.firebaseapp.com",
  projectId: "dadok-c9f63",
  storageBucket: "dadok-c9f63.appspot.com",
  messagingSenderId: "1015071404890",
  appId: "1:1015071404890:web:d6f65a2da2d1c3b3ef3963",
  measurementId: "G-TMNHP5LV43",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);
const storageRef = ref(storage);
console.log(storageRef); // 스토리지 루트

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
