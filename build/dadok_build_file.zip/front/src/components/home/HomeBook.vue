<template>
  <div class="homebook">
    <!-- <b-container class="bv-example-row">
      <h6 style="padding: 20px 20px 0px 20px">독서모임 책 추천</h6>
      <h4 style="padding: 0px 20px 20px 20px">베스트셀러에서 골라보세요</h4>
      <b-row style="text-align: center; padding: 0px 0px 50px 0px">
        <b-col>
          <div class="bookimg">
            <img src="https://picsum.photos/id/151/200/300" alt="" />
          </div>
        </b-col>
        <b-col>
          <div>
            <img src="https://picsum.photos/id/152/200/300" alt="" />
          </div>
        </b-col>
        <b-col>
          <div>
            <img src="https://picsum.photos/id/153/200/300" alt="" />
          </div>
        </b-col>
        <b-col><img src="https://picsum.photos/id/154/200/300" alt="" /></b-col>
      </b-row>
    </b-container> -->
  </div>
</template>

<script>
export default {};
</script>

<style>
.homebook {
  background-color: #fef7dc;
}
.bookimg {
  border-radius: 70%;
}
</style>
