<template>
  <div class="mt-4 container">
    <div>
      <div class="mt-3">
        <div class="my-2">
          <h2><strong>내 서재_V1</strong></h2>
        </div>
        <br />
        <div>
          <b-row style="text-align: center; padding: 0px 0px 50px 0px">
            <b-col>
              <div class="bookimg">
                <img src="https://picsum.photos/id/151/200/300" alt="" />
              </div>
            </b-col>
            <b-col>
              <div>
                <img src="https://picsum.photos/id/152/200/300" alt="" />
              </div>
            </b-col>
            <b-col>
              <div>
                <img src="https://picsum.photos/id/153/200/300" alt="" />
              </div>
            </b-col>
            <b-col><img src="https://picsum.photos/id/154/200/300" alt="" /></b-col>
          </b-row>
          <b-row style="text-align: center; padding: 0px 0px 50px 0px">
            <b-col>
              <div class="bookimg">
                <img src="https://picsum.photos/id/151/200/300" alt="" />
              </div>
            </b-col>
            <b-col>
              <div>
                <img src="https://picsum.photos/id/152/200/300" alt="" />
              </div>
            </b-col>
            <b-col>
              <div>
                <img src="https://picsum.photos/id/153/200/300" alt="" />
              </div>
            </b-col>
            <b-col><img src="https://picsum.photos/id/154/200/300" alt="" /></b-col>
          </b-row>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
