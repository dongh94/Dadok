<template>
  <div style="background-color: #f4ece1; opacity: 0.8">
    <br />
    <div class="container">
      <div>
        <strong> 주식회사 H1K4 </strong>
      </div>
      <span>주소 : 대전광역시 유성구 동서대로 98-39 삼성화재 유성연구원</span>
      <br />
      <span>이메일 : dadok@gmail.com</span><br />
      <span>Copyright © H1K4 All Rights Reserved.</span>
    </div>
    <br />
  </div>
</template>

<script>
export default {};
</script>

<style></style>
