<template>
  <div class="mt-4 container">
    <!-- <b-card class="shadow-lg p-3 mb-5 bg-body rounded">
      <div class="">
        <div class="">
          <h2><strong>목표 달성률</strong></h2>
        </div>
        <br />
        <b-row align-v="center">
          <b-col cols="2">
            <h4 class="mx-3">출석률</h4>
          </b-col>
          <b-col cols="10">
            <div class="progress">
              <div class="progress-bar progress-bar-success active" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%; background-color: #5c4a31"></div>
            </div>
          </b-col>
        </b-row>
        <b-row align-v="center">
          <b-col cols="2">
            <h4 class="mx-3">읽은 책</h4>
          </b-col>
          <b-col cols="10">
            <div class="progress">
              <div
                class="progress-bar progress-bar-success progress-bar-striped active"
                role="progressbar"
                aria-valuenow="50"
                aria-valuemin="0"
                aria-valuemax="100"
                style="width: 50%; background-color: #b09b71"
              ></div>
            </div>
          </b-col>
        </b-row>

        <b-row align-v="center">
          <b-col cols="2">
            <h4 class="mx-3">모임 시간</h4>
          </b-col>
          <b-col cols="10">
            <div class="progress">
              <div class="progress-bar progress-bar-success active" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 90%; background-color: #a19882"></div>
            </div>
          </b-col>
        </b-row>
        <b-row align-v="center">
          <b-col cols="2">
            <h4 class="mx-3">모임 횟수</h4>
          </b-col>
          <b-col cols="10">
            <div class="progress">
              <div class="progress-bar progress-bar-success active" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%; background-color: #e6ddc6"></div>
            </div>
          </b-col>
        </b-row>
      </div>
    </b-card> -->
  </div>
</template>

<script>
export default {};
</script>

<style>
b-progress {
  color: blue;
}
</style>
