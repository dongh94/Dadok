<template>
  <make-group></make-group>
</template>

<script>
import MakeGroup from "@/components/MakeGroup.vue";
export default {
  name: "MakeGroupView",
  components: { MakeGroup },
};
</script>

<style>
@font-face {
  font-family: "Dosuguan";
  src: url("https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_three@1.0/도서관체.woff") format("woff");
  font-weight: normal;
  font-style: normal;
}
</style>
