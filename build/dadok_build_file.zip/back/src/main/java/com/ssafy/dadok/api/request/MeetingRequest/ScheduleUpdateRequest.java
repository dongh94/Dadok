package com.ssafy.dadok.api.request.MeetingRequest;


import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class ScheduleUpdateRequest {
    String schedule;
}
