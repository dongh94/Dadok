package com.ssafy.dadok.api.request.SheetUpdateRequest;


import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class ImgPathDto {
    String img_path;
}
