package com.ssafy.dadok.common.exception.handler;

public class NotFoundHandler {
}
