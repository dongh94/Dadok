package com.ssafy.dadok.api.request.UserRequest;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class IntroduceUpdateRequest {

    private String introduce;
}
