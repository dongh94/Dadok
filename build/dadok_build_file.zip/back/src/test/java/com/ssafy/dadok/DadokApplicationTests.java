package com.ssafy.dadok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DadokApplicationTests {

	@Test
	void contextLoads() {
	}

}
