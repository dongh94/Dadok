var express = require("express");

const app = express();
const http = require("http");
const httpServer = http.createServer(app);

const io = require("socket.io")(httpServer, {
  cors: {
    //origin: "http://localhost:3001",
    origin: "http://i7b109.p.ssafy.io:3001",
    credentials: true,
  },
});
//const { Server } = require("socket.io");
//const io = new Server(httpServer, { path: "/socket" });
//setting cors
// app.all("/*", function (req, res, next) {
//   res.header("Access-Control-Allow-Origin", "*");
//   res.header("Access-Control-Allow-Headers", "X-Requested-With");
//   next();
// });

app.get("/ws/sk/", (req, res) => {
  res.send("Hellow Chating App Server");
// 클라이언트가 접속했을 수행됨
io.on("connection", (socket) => {
  //console.log(socket);
  console.log("접속");
  socket.on("chat", (val) => {
    io.emit("chat", val);
  });
  socket.on("sheet", (val) => {
    io.emit("sheet", val);
  });
  socket.on("session", (val) => {
    io.emit("session", val);
  });
});
});
// app.get("/nd/", (req, res) => {
//   res.send("Hellow");
// });

httpServer.listen(3001, () => {
  console.log("http:i7b109.p.ssafy.io:3001/socket");
});

// 클라이언트가 접속했을 수행됨
io.on("connection", (socket) => {
  //console.log(socket);
  console.log("접속");
  socket.on("chat", (val) => {
    io.emit("chat", val);
  });
  socket.on("sheet", (val) => {
    io.emit("sheet", val);
  });
  socket.on("session", (val) => {
    io.emit("session", val);
  });
});
